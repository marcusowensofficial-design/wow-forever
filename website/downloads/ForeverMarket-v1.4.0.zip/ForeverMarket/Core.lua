local addonName, ns = ...

-- ============================================================================
-- ForeverMarket v1.4.0 — Zero-Taint Auction House Scanner & Website Bridge
-- Built for WoW Forever (Camelot 12.0 / Interface 16001)
-- ============================================================================

local ADDON_PREFIX = "|cff00ccff[ForeverMarket]|r "
local VERSION = "1.4.0"

-- The server allows one full replication scan (C_AuctionHouse.ReplicateItems)
-- every 15 minutes. A request made during the cooldown is silently ignored:
-- no error, no REPLICATE_ITEM_LIST_UPDATE, so it would only end in a timeout.
local REPLICATE_COOLDOWN = 15 * 60
local SCAN_TIMEOUT = 90

local DEFAULT_DB = {
    version = VERSION,
    settings = {
        showTooltips = true,
        autoScanOnOpen = false,
        maxHistoryDays = 14
    },
    realms = {},
    shoppingList = {}
}

-- 12.0 Secret Value Guard
local function CanAccess(val)
    if val == nil then return false end
    if canaccessvalue and not canaccessvalue(val) then return false end
    if issecretvalue and issecretvalue(val) then return false end
    return true
end

-- Ruleset-aware realm identifier (WoW Forever has no traditional server names)
local function GetMakeshiftRealmName()
    local _, _, _, buildVersion = GetBuildInfo()
    if buildVersion and buildVersion > 16000 and buildVersion < 20000 then
        if C_GameRules and C_GameRules.IsGameRuleActive and Enum and Enum.GameRule then
            if Enum.GameRule.HardcoreRuleset and C_GameRules.IsGameRuleActive(Enum.GameRule.HardcoreRuleset) then
                return "Hardcore"
            elseif Enum.GameRule.RPRuleset and C_GameRules.IsGameRuleActive(Enum.GameRule.RPRuleset) then
                return "RP"
            elseif Enum.GameRule.PvPRuleset and C_GameRules.IsGameRuleActive(Enum.GameRule.PvPRuleset) then
                return "PvP"
            else
                return "PvE"
            end
        end
    end
    local realm = GetRealmName and GetRealmName() or ""
    if CanAccess(realm) and realm ~= "" then
        return realm
    end
    return "PvE"
end

local function GetRealmFactionKey()
    local ruleset = GetMakeshiftRealmName()
    local faction = UnitFactionGroup and UnitFactionGroup("player") or "Neutral"
    if not CanAccess(faction) or faction == "" then
        faction = "Neutral"
    end
    return ruleset .. "_" .. faction
end

local function MergeDefaults(src, dest)
    if type(src) ~= "table" then return {} end
    if type(dest) ~= "table" then dest = {} end
    for k, v in pairs(src) do
        if type(v) == "table" then
            dest[k] = MergeDefaults(v, dest[k])
        elseif dest[k] == nil then
            dest[k] = v
        end
    end
    return dest
end

local function FormatCopper(copper)
    if not CanAccess(copper) or type(copper) ~= "number" or copper <= 0 then
        return "|cff888888N/A|r"
    end
    local g = math.floor(copper / 10000)
    local s = math.floor((copper % 10000) / 100)
    local c = math.floor(copper % 100)
    local parts = {}
    if g > 0 then
        table.insert(parts, string.format("|cffffd700%dg|r", g))
    end
    if s > 0 or g > 0 then
        table.insert(parts, string.format("|cffc7c7cf%ds|r", s))
    end
    table.insert(parts, string.format("|cffeda55f%dc|r", c))
    return table.concat(parts, " ")
end

local function GetTodayDayNumber()
    return math.floor(time() / 86400)
end

local function GetActiveBucket()
    ForeverMarketDB = MergeDefaults(DEFAULT_DB, ForeverMarketDB)
    local key = GetRealmFactionKey()
    if not ForeverMarketDB.realms[key] then
        ForeverMarketDB.realms[key] = {
            ruleset = GetMakeshiftRealmName(),
            faction = UnitFactionGroup and UnitFactionGroup("player") or "Alliance",
            lastScanTime = 0,
            lastScanCount = 0,
            items = {}
        }
    end
    return ForeverMarketDB.realms[key], key
end

-- ============================================================================
-- Item Link Parsing — random suffix ("of the Eagle", "of the Monkey", ...)
-- itemString layout: item:itemID:enchantID:gem1:gem2:gem3:gem4:suffixID:uniqueID:...
-- The suffixID (field 7) is what distinguishes Knight's Pauldrons of the Eagle
-- from Knight's Pauldrons of the Wolf. 0 / empty = no random suffix.
-- ============================================================================
local function ParseItemLink(link)
    if not CanAccess(link) or type(link) ~= "string" then return nil, 0 end
    local itemString = link:match("item:([%-%d:]+)")
    if not itemString then return nil, 0 end
    local fields = {}
    for f in (itemString .. ":"):gmatch("([^:]*):") do
        fields[#fields + 1] = f
    end
    local itemID = tonumber(fields[1])
    local suffixID = tonumber(fields[7]) or 0
    return itemID, suffixID
end

local function SafeString(s)
    if CanAccess(s) and type(s) == "string" and s ~= "" then return s end
    return nil
end

-- Base (unsuffixed) item name from the client cache, if available
local function GetBaseItemName(itemID)
    if C_Item and C_Item.GetItemInfo then
        local ok, name = pcall(C_Item.GetItemInfo, itemID)
        if ok then return SafeString(name) end
    elseif GetItemInfo then
        local ok, name = pcall(GetItemInfo, itemID)
        if ok then return SafeString(name) end
    end
    return nil
end

-- "Knight's Pauldrons of the Eagle" + base "Knight's Pauldrons" -> "of the Eagle"
local function GetSuffixLabel(fullName, baseName)
    if not fullName then return nil end
    if baseName and fullName:sub(1, #baseName) == baseName and #fullName > #baseName then
        local label = fullName:sub(#baseName + 1):gsub("^%s+", "")
        if label ~= "" then return label end
    end
    return fullName
end

-- Record an observed listing into the current scan buffer
local activeScanBuffer = {}
local isScanning = false
local scanPage = 0
local unresolvedLinks = 0
local unresolvedItemIDs = {} -- itemIDs whose link wasn't cached yet (to request their data)

local function RecordObservedItem(itemID, count, buyoutPrice, minBid, itemName, itemLink)
    if not CanAccess(itemID) or not CanAccess(count) or not CanAccess(buyoutPrice) then
        return
    end
    if type(itemID) ~= "number" or itemID <= 0 then return end
    if type(count) ~= "number" or count <= 0 then count = 1 end

    local unitPrice = 0
    if type(buyoutPrice) == "number" and buyoutPrice > 0 then
        unitPrice = math.floor(buyoutPrice / count)
    elseif CanAccess(minBid) and type(minBid) == "number" and minBid > 0 then
        unitPrice = math.floor(minBid / count)
    end
    if unitPrice <= 0 then return end

    local name = SafeString(itemName)
    local linkItemID, suffixID = ParseItemLink(itemLink)
    if not linkItemID then
        unresolvedLinks = unresolvedLinks + 1
        unresolvedItemIDs[itemID] = true
    end

    -- Base (per itemID) aggregate: cheapest of ANY suffix, total supply
    local entry = activeScanBuffer[itemID]
    if not entry then
        entry = { minBuyout = unitPrice, totalQty = 0, listings = 0, name = nil, variants = nil }
        activeScanBuffer[itemID] = entry
    end
    if unitPrice < entry.minBuyout then entry.minBuyout = unitPrice end
    entry.totalQty = entry.totalQty + count
    entry.listings = entry.listings + 1
    if suffixID == 0 and not entry.name then entry.name = name end

    -- Per-suffix variant: priced independently
    if suffixID ~= 0 then
        entry.variants = entry.variants or {}
        local vKey = tostring(suffixID)
        local v = entry.variants[vKey]
        if not v then
            v = { minBuyout = unitPrice, totalQty = 0, listings = 0, name = name }
            entry.variants[vKey] = v
        end
        if unitPrice < v.minBuyout then v.minBuyout = unitPrice end
        v.totalQty = v.totalQty + count
        v.listings = v.listings + 1
        if not v.name then v.name = name end
    end
end

local function PruneHistory(history, cutoffDay)
    for dKey in pairs(history) do
        local dVal = tonumber(dKey)
        if dVal and dVal < cutoffDay then
            history[dKey] = nil
        end
    end
end

-- Plain-English reason for missing links, from a scan's saved diagnostics
local function DescribeLinkDiag(d)
    if type(d) ~= "table" or not d.rows or d.rows == 0 then return nil end
    if d.apiMissing then
        return "This client has no C_AuctionHouse.GetReplicateItemLink, so full scans can't see item links."
    elseif d.errors > 0 and d.withLink == 0 then
        return "GetReplicateItemLink raised an error: " .. tostring(d.errSample)
    elseif d.secret > 0 and d.withLink == 0 then
        return string.format("The client returned item links as protected (secret) values on %d rows, which addons can't read.", d.secret)
    elseif d.parseFail > 0 then
        return string.format("%d links came back in an unexpected format and couldn't be parsed. Example: %s", d.parseFail, (tostring(d.sample):gsub("|", "||")))
    elseif (d.stillPending or 0) > 0 then
        return string.format("The client hadn't finished loading item data (%d of %d rows reported hasAllInfo = false at first read).", d.notLoaded or 0, d.rows)
    end
    return nil
end
ns.DescribeLinkDiag = DescribeLinkDiag

local function CommitScanBuffer()
    local bucket, key = GetActiveBucket()
    local now = time()
    local dayNum = GetTodayDayNumber()
    local dayKey = tostring(dayNum)
    local maxDays = (ForeverMarketDB.settings and ForeverMarketDB.settings.maxHistoryDays) or 14
    local cutoffDay = dayNum - maxDays

    local updatedItems, updatedVariants, totalListings = 0, 0, 0
    for itemID, data in pairs(activeScanBuffer) do
        updatedItems = updatedItems + 1
        totalListings = totalListings + (data.listings or 0)
        local rec = bucket.items[itemID]
        if not rec then
            rec = { history = {} }
            bucket.items[itemID] = rec
        end
        if type(rec.history) ~= "table" then rec.history = {} end

        rec.minBuyout = data.minBuyout
        rec.qty = data.totalQty
        rec.listings = data.listings
        rec.lastSeen = now
        local baseName = GetBaseItemName(itemID) or data.name
        if baseName then rec.name = baseName end

        rec.history[dayKey] = data.minBuyout
        PruneHistory(rec.history, cutoffDay)

        if data.variants then
            rec.hasVariants = true
            rec.variants = type(rec.variants) == "table" and rec.variants or {}
            for vKey, vData in pairs(data.variants) do
                updatedVariants = updatedVariants + 1
                local v = rec.variants[vKey]
                if not v then
                    v = { history = {} }
                    rec.variants[vKey] = v
                end
                if type(v.history) ~= "table" then v.history = {} end
                v.minBuyout = vData.minBuyout
                v.qty = vData.totalQty
                v.listings = vData.listings
                v.lastSeen = now
                if vData.name then
                    v.name = vData.name
                    v.suffix = GetSuffixLabel(vData.name, rec.name)
                end
                v.history[dayKey] = vData.minBuyout
                PruneHistory(v.history, cutoffDay)
            end
        end
    end

    if updatedItems > 0 then
        -- Previous scan's link stats (nil on the first scan after this version)
        local prevUnresolved = tonumber(bucket.lastUnresolved)
        local prevListings = tonumber(bucket.lastListings)

        bucket.lastScanTime = now
        bucket.lastScanCount = updatedItems
        bucket.lastListings = totalListings
        bucket.lastUnresolved = unresolvedLinks
        print(string.format("%sCommitted |cffffd100%d|r unique items (|cffffd100%d|r suffix variants) to SavedVariables (%s). Use |cff00ff98/reload|r to flush to disk for website sync.", ADDON_PREFIX, updatedItems, updatedVariants, key))

        local resolved = totalListings - unresolvedLinks
        local pct = totalListings > 0 and math.floor(resolved * 100 / totalListings) or 0
        local linksLine = string.format("Item links: |cffffd100%d|r of |cffffd100%d|r listings (|cffffd100%d%%|r)", resolved, totalListings, pct)

        if unresolvedLinks == 0 then
            if prevUnresolved and prevUnresolved > 0 then
                print(string.format("%s|cff00ff98Scan complete — all item links resolved|r (last scan was missing %d). %s. Suffix variants are now priced individually.", ADDON_PREFIX, prevUnresolved, linksLine))
            else
                print(string.format("%s|cff00ff98Scan complete.|r %s.", ADDON_PREFIX, linksLine))
            end
        elseif resolved == 0 and prevUnresolved and prevListings and prevUnresolved >= prevListings then
            -- Two scans in a row with zero links: the client isn't returning links for
            -- replicated listings at all, so waiting and re-scanning won't change anything.
            print(string.format("%s|cffff9933Scan saved, but this scan also returned no item links|r (0 of %d, same as last scan). Re-scanning won't fix this: the client isn't providing links for full-scan listings. Base-item prices are saved; suffix variants (\"of the Eagle\" etc.) can't be priced separately.", ADDON_PREFIX, totalListings))
        else
            local progress = ""
            if prevUnresolved and prevUnresolved > 0 then
                local fixed = prevUnresolved - unresolvedLinks
                if fixed > 0 then
                    progress = string.format(" |cff00ff98Re-scan resolved %d|r that were missing last time.", fixed)
                else
                    progress = " |cffff9933No improvement over last scan.|r"
                end
            end
            -- Say WHEN a re-scan can run: the server ignores one inside the 15-minute cooldown.
            local remaining = ns.GetReplicateCooldownRemaining and ns.GetReplicateCooldownRemaining() or 0
            local when
            if remaining > 0 then
                local readyAt = tostring(date("%I:%M %p", time() + remaining)):gsub("^0", "")
                when = string.format("A re-scan after |cffffd100%s|r (one full scan per 15 minutes) may resolve more.", readyAt)
            else
                when = "Re-scan now to try to resolve more."
            end
            print(string.format("%sScan saved. %s;|cffff9933 %d|r had no link and were priced at base-item level only.%s %s", ADDON_PREFIX, linksLine, unresolvedLinks, progress, when))
        end
        if unresolvedLinks > 0 then
            local reason = DescribeLinkDiag(bucket.lastLinkDiag)
            if reason then
                print(string.format("%s|cff888888Why:|r %s Type |cffffd100/fm linkcheck|r for details.", ADDON_PREFIX, reason))
            end
        end
        if _G.ForeverLiquid and _G.ForeverLiquid.OnMarketDataUpdated then
            pcall(_G.ForeverLiquid.OnMarketDataUpdated, _G.ForeverLiquid)
        end
    end

    activeScanBuffer = {}
    unresolvedLinks = 0
    unresolvedItemIDs = {}
    isScanning = false
    if ns.UpdateScanButtonState then ns.UpdateScanButtonState() end
end

-- Classic / Hybrid Auction House List Scanner
local function ScanCurrentClassicPage()
    if not GetNumAuctionItems or not GetAuctionItemInfo then return 0 end
    local batch, total = GetNumAuctionItems("list")
    if not CanAccess(batch) or type(batch) ~= "number" or batch <= 0 then
        return 0, 0
    end

    for i = 1, batch do
        local name, _, count, _, _, _, _, minBid, _, buyoutPrice, _, _, _, _, _, _, itemID = GetAuctionItemInfo("list", i)
        local link = GetAuctionItemLink and GetAuctionItemLink("list", i) or nil
        if not CanAccess(link) or type(link) ~= "string" then link = nil end
        if (not itemID or itemID == 0) and link then
            itemID = ParseItemLink(link)
        end
        if itemID then
            RecordObservedItem(itemID, count, buyoutPrice, minBid, name, link)
        end
    end
    return batch, (CanAccess(total) and total or batch)
end

-- ============================================================================
-- Modern C_AuctionHouse ReplicateItems Scanner (Camelot 12.0 Engine)
--
-- Replication delivers every listing at once, but a row's item link only
-- exists once the client has loaded that item (GetReplicateItemInfo's 18th
-- return, hasAllInfo). So:
--   1. Read every row once. Rows with a link are recorded straight away; rows
--      without one have their price data saved in pending arrays.
--   2. Ask the client to load the missing items, then every RETRY_DELAY
--      seconds re-check ONLY the pending rows' links (cheap, unlike re-reading
--      all ~170k rows), while the pending count keeps dropping.
--   3. Whatever is still pending is recorded at base-item level from the
--      saved data, so a slow cache or a closed AH never loses prices.
-- ============================================================================
local REPLICATE_RETRY_DELAY = 2
local REPLICATE_MAX_WAIT = 60   -- total seconds to wait for links
local REPLICATE_STALL_TIME = 10 -- give up after this long with no progress
local replicateCollected = false -- first pass done for the current scan
local replicatePending = false   -- a retry timer is scheduled
local replicateWaitStart = 0
local replicateLastProgress = 0
local replicateLastPending = math.huge
local replicateLastReport = 0

-- Pending rows (parallel arrays keep memory low for 100k+ rows)
local pIdx, pItem, pCount, pBuy, pBid, pName = {}, {}, {}, {}, {}, {}

-- Why links were missing on the first pass (kept for /fm linkcheck)
local linkDiag = {}

local function ResetReplicateState()
    replicateCollected = false
    replicatePending = false
    replicateWaitStart = 0
    replicateLastProgress = 0
    replicateLastPending = math.huge
    replicateLastReport = 0
    pIdx, pItem, pCount, pBuy, pBid, pName = {}, {}, {}, {}, {}, {}
    linkDiag = {
        rows = 0, withLink = 0, notLoaded = 0, apiMissing = false,
        errors = 0, secret = 0, empty = 0, parseFail = 0, sample = nil, errSample = nil,
    }
end
ResetReplicateState()

-- Returns the row's link or nil, and records why it was nil in linkDiag
-- when diag is true (first pass only).
local function GetRowLink(i, diag)
    if not C_AuctionHouse.GetReplicateItemLink then
        if diag then linkDiag.apiMissing = true end
        return nil
    end
    local ok, l = pcall(C_AuctionHouse.GetReplicateItemLink, i)
    if not ok then
        if diag then
            linkDiag.errors = linkDiag.errors + 1
            linkDiag.errSample = linkDiag.errSample or tostring(l)
        end
        return nil
    end
    if l == nil then return nil end
    if not CanAccess(l) then
        if diag then linkDiag.secret = linkDiag.secret + 1 end
        return nil
    end
    if type(l) ~= "string" or l == "" then
        if diag then linkDiag.empty = linkDiag.empty + 1 end
        return nil
    end
    if not ParseItemLink(l) then
        -- A link came back but isn't in the item:ID:... shape we parse
        if diag then
            linkDiag.parseFail = linkDiag.parseFail + 1
            linkDiag.sample = linkDiag.sample or l
        end
        return nil
    end
    return l
end

local function AddPending(i, itemID, count, buyoutPrice, minBid, name)
    local n = #pIdx + 1
    pIdx[n], pItem[n], pCount[n], pBuy[n], pBid[n], pName[n] = i, itemID, count, buyoutPrice, minBid, name or false
    unresolvedItemIDs[itemID] = true
end

-- First pass over the whole replicated list
local function ScanReplicatedItems()
    if not C_AuctionHouse or not C_AuctionHouse.GetNumReplicateItems or not C_AuctionHouse.GetReplicateItemInfo then
        return 0
    end
    local numItems = C_AuctionHouse.GetNumReplicateItems()
    if not CanAccess(numItems) or type(numItems) ~= "number" or numItems <= 0 then
        return 0
    end

    for i = 0, numItems - 1 do
        local name, _, count, _, _, _, _, minBid, _, buyoutPrice, _, _, _, _, _, _, itemID, hasAllInfo = C_AuctionHouse.GetReplicateItemInfo(i)
        linkDiag.rows = linkDiag.rows + 1
        if hasAllInfo == false then linkDiag.notLoaded = linkDiag.notLoaded + 1 end
        local link = GetRowLink(i, true)
        if link then linkDiag.withLink = linkDiag.withLink + 1 end
        if (not itemID or itemID == 0) and link then
            itemID = ParseItemLink(link)
        end
        if CanAccess(itemID) and type(itemID) == "number" and itemID > 0 then
            if link then
                RecordObservedItem(itemID, count, buyoutPrice, minBid, name, link)
            else
                AddPending(i, itemID, count, buyoutPrice, minBid, name)
            end
        end
    end
    return numItems
end

-- Re-check only the pending rows; keep those still missing a link
local function RetryPendingRows()
    local nIdx, nItem, nCount, nBuy, nBid, nName = {}, {}, {}, {}, {}, {}
    unresolvedItemIDs = {}
    for k = 1, #pIdx do
        local link = GetRowLink(pIdx[k], false)
        if link then
            -- The link may carry the suffixed name; fall back to the saved one
            RecordObservedItem(pItem[k], pCount[k], pBuy[k], pBid[k], pName[k] or nil, link)
        else
            local n = #nIdx + 1
            nIdx[n], nItem[n], nCount[n], nBuy[n], nBid[n], nName[n] = pIdx[k], pItem[k], pCount[k], pBuy[k], pBid[k], pName[k]
            unresolvedItemIDs[pItem[k]] = true
        end
    end
    pIdx, pItem, pCount, pBuy, pBid, pName = nIdx, nItem, nCount, nBuy, nBid, nName
end

-- Record every still-pending row at base-item level (counts as unresolved)
local function FlushPendingRows()
    for k = 1, #pIdx do
        RecordObservedItem(pItem[k], pCount[k], pBuy[k], pBid[k], pName[k] or nil, nil)
    end
    pIdx, pItem, pCount, pBuy, pBid, pName = {}, {}, {}, {}, {}, {}
end
ns.FlushPendingRows = FlushPendingRows

local function RequestUnresolvedItemData()
    if not (C_Item and C_Item.RequestLoadItemDataByID) then return end
    for itemID in pairs(unresolvedItemIDs) do
        pcall(C_Item.RequestLoadItemDataByID, itemID)
    end
end

-- ============================================================================
-- Sales Velocity (v1.3)
-- The AH has no "sold" feed, so sales are inferred by diffing two full scans:
--   * Every scan saves a compact snapshot of all listings, keyed by
--     buyout:count:seller, with each listing's time-left band.
--   * A listing that vanished although its time-left band guarantees it would
--     still be up was bought or cancelled. If the same seller posted new
--     listings of that item meanwhile, it's treated as cancel-and-repost.
-- This is a LOWER BOUND: listings in the "short" band, and listings posted
-- and bought between two scans, are invisible to it.
-- ============================================================================
local TL_MIN_REMAINING = { [1] = 0, [2] = 30 * 60, [3] = 2 * 3600, [4] = 12 * 3600 }
local VELOCITY_MAX_GAP = 12 * 3600 -- past this, no band guarantees a listing survived
local VELOCITY_WINDOW_DAYS = 7
local SNAPSHOT_CHUNK = 20000       -- replicated rows read per frame
local velocityBusy = false

local function GetSnapshotStore()
    if type(ForeverMarketSnapshotDB) ~= "table" then ForeverMarketSnapshotDB = {} end
    return ForeverMarketSnapshotDB
end

local function FormatDuration(secs)
    secs = math.max(0, math.floor(secs))
    if secs < 3600 then return string.format("%dm", math.floor(secs / 60)) end
    return string.format("%dh %02dm", math.floor(secs / 3600), math.floor((secs % 3600) / 60))
end

-- Saved item string -> { ["buyout:count:owner"] = n * 10 + band }
local function DecodeSnapshotItem(str, owners)
    local t = {}
    if type(str) ~= "string" then return t end
    for b, c, oi, n, band in str:gmatch("(%d+):(%d+):(%d+):(%d+):(%d+);") do
        local owner = (oi ~= "0" and owners[tonumber(oi)]) or "?"
        t[b .. ":" .. c .. ":" .. owner] = tonumber(n) * 10 + tonumber(band)
    end
    return t
end

-- Units of one item sold between two snapshots (see section header)
local function EstimateItemSales(prevT, curT, gap)
    local left = {}
    for k, v in pairs(curT) do left[k] = math.floor(v / 10) end
    local gone = {} -- [seller] = units that vanished early
    for k, v in pairs(prevT) do
        local n, band = math.floor(v / 10), v % 10
        local m = math.min(n, left[k] or 0)
        if m > 0 then left[k] = left[k] - m end
        local rest = n - m
        if rest > 0 then
            local b, c, owner = k:match("^(%d+):(%d+):(.*)$")
            c = tonumber(c) or 1
            if b and owner ~= "?" then
                -- Same listing, but its seller wasn't loaded in this scan
                local alt = b .. ":" .. c .. ":?"
                local m2 = math.min(rest, left[alt] or 0)
                if m2 > 0 then left[alt] = left[alt] - m2; rest = rest - m2 end
                if rest > 0 and band > 0 and gap < (TL_MIN_REMAINING[band] or 0) then
                    gone[owner] = (gone[owner] or 0) + rest * c
                end
            end
        end
    end
    if not next(gone) then return 0 end
    local reposted = {}
    for k, n in pairs(left) do
        if n > 0 then
            local _, c, owner = k:match("^(%d+):(%d+):(.*)$")
            if owner and gone[owner] then
                reposted[owner] = (reposted[owner] or 0) + n * (tonumber(c) or 1)
            end
        end
    end
    local units = 0
    for owner, g in pairs(gone) do
        units = units + math.max(0, g - (reposted[owner] or 0))
    end
    return units
end

-- Estimated units sold per day over the last week, and seconds of coverage
local function GetSalesPerDay(rec, bucket)
    if type(rec) ~= "table" or type(bucket) ~= "table" or type(bucket.observed) ~= "table" then return nil, 0 end
    local today = GetTodayDayNumber()
    local secs, units = 0, 0
    for d = today - VELOCITY_WINDOW_DAYS + 1, today do
        local k = tostring(d)
        secs = secs + (bucket.observed[k] or 0)
        if type(rec.sold) == "table" then units = units + (rec.sold[k] or 0) end
    end
    if secs < 3600 then return nil, secs end
    return units * 86400 / secs, secs
end
ns.GetSalesPerDay = GetSalesPerDay

local function FinishVelocity(cur, rows, oneBased, hasTL)
    velocityBusy = false
    local bucket, key = GetActiveBucket()
    local store = GetSnapshotStore()
    local prev = store[key]
    local now = time()

    -- Normalize bands to 1..4 (rows were stored as raw + 1; 0 = unknown)
    if oneBased then
        for _, t in pairs(cur) do
            for k, v in pairs(t) do
                if v % 10 > 0 then t[k] = v - 1 end
            end
        end
    end

    local msg
    if type(prev) == "table" and type(prev.items) == "table" and tonumber(prev.time) then
        local gap = now - prev.time
        if not hasTL then
            msg = "|cffff9933Sales tracking unavailable:|r this client doesn't report auction time-left."
        elseif gap > VELOCITY_MAX_GAP then
            msg = string.format("Sales tracking: previous scan was %s ago (over 12h), so this scan starts a new comparison.", FormatDuration(gap))
        elseif (tonumber(prev.rows) or 0) > 0 and rows < prev.rows * 0.7 then
            msg = string.format("|cffff9933Sales tracking skipped:|r this scan saw %d listings vs %d last time, which looks like a partial scan.", rows, prev.rows)
        elseif gap > 0 then
            local owners = type(prev.owners) == "table" and prev.owners or {}
            local dayNum = GetTodayDayNumber()
            local dayKey = tostring(dayNum)
            local cutoff = dayNum - ((ForeverMarketDB.settings and ForeverMarketDB.settings.maxHistoryDays) or 14)
            local totalUnits, totalItems = 0, 0
            for itemID, str in pairs(prev.items) do
                local units = EstimateItemSales(DecodeSnapshotItem(str, owners), cur[itemID] or {}, gap)
                local rec = units > 0 and bucket.items[itemID]
                if rec then
                    rec.sold = type(rec.sold) == "table" and rec.sold or {}
                    rec.sold[dayKey] = (rec.sold[dayKey] or 0) + units
                    PruneHistory(rec.sold, cutoff)
                    totalUnits = totalUnits + units
                    totalItems = totalItems + 1
                end
            end
            bucket.observed = type(bucket.observed) == "table" and bucket.observed or {}
            bucket.observed[dayKey] = (bucket.observed[dayKey] or 0) + gap
            PruneHistory(bucket.observed, cutoff)
            msg = string.format("Sales tracking: ~|cffffd100%d|r units across |cffffd100%d|r items sold in the %s since the last scan. Type |cffffd100/fm top|r for the fastest movers.", totalUnits, totalItems, FormatDuration(gap))
        end
    else
        msg = "Sales tracking: first snapshot saved. Scan again within 12 hours to start estimating sales."
    end

    -- Save this scan as the next comparison base (sellers interned to save space)
    local owners, ownerIdx, items = {}, {}, {}
    for itemID, t in pairs(cur) do
        local parts = {}
        for k, v in pairs(t) do
            local b, c, owner = k:match("^(%d+):(%d+):(.*)$")
            local oi = 0
            if owner ~= "?" then
                oi = ownerIdx[owner]
                if not oi then
                    oi = #owners + 1
                    owners[oi] = owner
                    ownerIdx[owner] = oi
                end
            end
            parts[#parts + 1] = string.format("%s:%s:%d:%d:%d;", b, c, oi, math.floor(v / 10), v % 10)
        end
        items[itemID] = table.concat(parts)
    end
    store[key] = { time = now, rows = rows, owners = owners, items = items }
    if msg then print(ADDON_PREFIX .. msg) end
end

-- Reads every replicated row again (after links/owners had time to load),
-- SNAPSHOT_CHUNK rows per frame so 250k listings don't freeze the game.
local function StartVelocityUpdate()
    if velocityBusy then return end
    if not (C_AuctionHouse and C_AuctionHouse.GetNumReplicateItems and C_AuctionHouse.GetReplicateItemInfo) then return end
    local total = C_AuctionHouse.GetNumReplicateItems()
    if not CanAccess(total) or type(total) ~= "number" or total <= 0 then return end
    velocityBusy = true
    local getTL = C_AuctionHouse.GetReplicateItemTimeLeft
    local cur, rows, minRaw, hasTL = {}, 0, math.huge, false
    local i = 0
    local function step()
        if C_AuctionHouse.GetNumReplicateItems() ~= total then
            velocityBusy = false
            print(ADDON_PREFIX .. "|cffff9933Sales tracking skipped:|r the auction data changed while it was being read (was the AH closed?).")
            return
        end
        local stop = math.min(total, i + SNAPSHOT_CHUNK)
        while i < stop do
            local _, _, count, _, _, _, _, _, _, buyout, _, _, _, owner, _, _, itemID = C_AuctionHouse.GetReplicateItemInfo(i)
            if CanAccess(itemID) and type(itemID) == "number" and itemID > 0
                and CanAccess(buyout) and type(buyout) == "number" and buyout > 0 then
                if not CanAccess(count) or type(count) ~= "number" or count <= 0 then count = 1 end
                local band = 0
                if getTL then
                    local ok, v = pcall(getTL, i)
                    if ok and CanAccess(v) and type(v) == "number" then
                        hasTL = true
                        if v < minRaw then minRaw = v end
                        band = math.max(1, math.min(5, v + 1))
                    end
                end
                local k = string.format("%d:%d:%s", buyout, count, SafeString(owner) or "?")
                local t = cur[itemID]
                if not t then t = {}; cur[itemID] = t end
                local v = t[k]
                if v then
                    -- Identical listings: keep the shortest band (conservative)
                    t[k] = (math.floor(v / 10) + 1) * 10 + math.min(v % 10, band)
                else
                    t[k] = 10 + band
                end
                rows = rows + 1
            end
            i = i + 1
        end
        if i < total then
            C_Timer.After(0, step)
        else
            -- Classic APIs report bands 1..4, modern enums 0..3
            FinishVelocity(cur, rows, minRaw >= 1, hasTL)
        end
    end
    step()
end

local function FinishReplicatedScan()
    -- Save the diagnostics so /fm linkcheck can explain the result later
    local bucket = GetActiveBucket()
    linkDiag.time = time()
    linkDiag.stillPending = #pIdx
    bucket.lastLinkDiag = linkDiag
    FlushPendingRows()
    CommitScanBuffer()
    StartVelocityUpdate()
end

local function ContinueReplicateWait()
    replicatePending = false
    if not isScanning then return end
    RetryPendingRows()
    local left = #pIdx
    if left == 0 then
        FinishReplicatedScan()
        return
    end
    local now = GetTime()
    if left < replicateLastPending then
        replicateLastPending = left
        replicateLastProgress = now
    end
    if now - replicateWaitStart < REPLICATE_MAX_WAIT and now - replicateLastProgress < REPLICATE_STALL_TIME then
        if now - replicateLastReport >= 10 then
            replicateLastReport = now
            print(string.format("%s...still loading: |cffffd100%d|r listings waiting for item links.", ADDON_PREFIX, left))
        end
        RequestUnresolvedItemData()
        replicatePending = true
        C_Timer.After(REPLICATE_RETRY_DELAY, ContinueReplicateWait)
        return
    end
    FinishReplicatedScan()
end

-- Called on REPLICATE_ITEM_LIST_UPDATE. Reading rows can itself fire that
-- event again, so only the first one per scan starts processing.
local function ProcessReplicatedScan()
    if not isScanning or replicateCollected then return end
    activeScanBuffer = {}
    unresolvedLinks = 0
    unresolvedItemIDs = {}
    local count = ScanReplicatedItems()
    if count <= 0 then return end
    replicateCollected = true

    if #pIdx == 0 then
        FinishReplicatedScan()
        return
    end
    if linkDiag.withLink == 0 and (linkDiag.apiMissing or linkDiag.errors + linkDiag.secret + linkDiag.parseFail > 0) then
        -- The link API itself isn't usable on this client; waiting can't help.
        FinishReplicatedScan()
        return
    end

    local now = GetTime()
    replicateWaitStart, replicateLastProgress, replicateLastReport = now, now, now
    replicateLastPending = #pIdx
    print(string.format("%sLoading |cffffd100%d|r item links before saving (up to %ds)...", ADDON_PREFIX, #pIdx, REPLICATE_MAX_WAIT))
    if ns.ArmScanTimeout then ns.ArmScanTimeout() end -- the wait gets its own timeout window
    RequestUnresolvedItemData()
    replicatePending = true
    C_Timer.After(REPLICATE_RETRY_DELAY, ContinueReplicateWait)
end

-- Most recent full-scan request we know of: ours (saved, so it survives /reload
-- and relog) or Auctionator's (it shares the same server cooldown, but only
-- keeps the time in memory on AuctionatorFullScanFrame.state).
local function GetLastReplicateRequest()
    local last = (ForeverMarketDB and tonumber(ForeverMarketDB.lastReplicateRequest)) or 0
    ---@diagnostic disable-next-line: undefined-field
    local atr = _G.AuctionatorFullScanFrame -- created by Auctionator at runtime; nil if not installed
    local atrState = type(atr) == "table" and type(atr.state) == "table" and atr.state or nil
    local atrLast = atrState and tonumber(atrState.TimeOfLastReplicateScan)
    if atrLast and atrLast > last then last = atrLast end
    return last
end

-- Seconds until the server accepts another full scan (0 = ready now)
local function GetReplicateCooldownRemaining()
    if not (C_AuctionHouse and C_AuctionHouse.ReplicateItems) then return 0 end
    local remaining = GetLastReplicateRequest() + REPLICATE_COOLDOWN - time()
    if remaining > REPLICATE_COOLDOWN then remaining = REPLICATE_COOLDOWN end -- clock skew guard
    return math.max(0, remaining)
end
ns.GetReplicateCooldownRemaining = GetReplicateCooldownRemaining

local function FormatCountdown(secs)
    return string.format("%d:%02d", math.floor(secs / 60), secs % 60)
end

-- Safety net: never leave a scan stuck if the server never answers.
-- scanToken makes a timer from an older scan ignore a newer one.
local scanToken = 0
local function ArmScanTimeout()
    scanToken = scanToken + 1
    local token = scanToken
    C_Timer.After(SCAN_TIMEOUT, function()
        if token ~= scanToken or not isScanning then return end
        if replicateCollected then
            -- Still waiting on links: save what we have (pending rows at base level)
            FinishReplicatedScan()
        elseif next(activeScanBuffer) then
            CommitScanBuffer()
        else
            isScanning = false
            replicatePending = false
            print(ADDON_PREFIX .. "Scan timed out: the server sent no auction data. This usually means another full scan (ForeverMarket, Auctionator or another character) ran in the last 15 minutes. Wait a few minutes and try again, or use |cffffd100/fm scan force|r if you're sure none did.")
        end
        if ns.UpdateScanButtonState then ns.UpdateScanButtonState() end
    end)
end
ns.ArmScanTimeout = ArmScanTimeout

-- Returns true if a scan was started. quiet = don't print the cooldown notice.
local function StartMarketScan(force, quiet)
    if isScanning then return false end

    -- Prefer C_AuctionHouse.ReplicateItems if available on 12.0 client
    if C_AuctionHouse and C_AuctionHouse.ReplicateItems then
        local remaining = GetReplicateCooldownRemaining()
        if remaining > 0 and not force then
            if not quiet then
                print(string.format("%sThe server only allows one full scan every 15 minutes. Next scan ready in |cffffd100%s|r.", ADDON_PREFIX, FormatCountdown(remaining)))
            end
            return false
        end
    end

    activeScanBuffer = {}
    unresolvedLinks = 0
    unresolvedItemIDs = {}
    isScanning = true
    scanPage = 0
    ResetReplicateState()

    if C_AuctionHouse and C_AuctionHouse.ReplicateItems then
        print(ADDON_PREFIX .. "Starting full Auction House replication scan...")
        ForeverMarketDB.lastReplicateRequest = time()
        pcall(C_AuctionHouse.ReplicateItems)
        ArmScanTimeout()
        return true
    end

    -- Fallback to Classic QueryAuctionItems getAll or paged scan
    if QueryAuctionItems and CanSendAuctionQuery then
        local canQuery, canQueryAll = CanSendAuctionQuery()
        if canQueryAll then
            print(ADDON_PREFIX .. "Starting fast full Auction House getAll scan...")
            QueryAuctionItems("", nil, nil, 0, false, 0, true, false, nil)
            ArmScanTimeout()
            return true
        elseif canQuery then
            print(ADDON_PREFIX .. "Starting paged Auction House scan (Page 1)...")
            QueryAuctionItems("", nil, nil, 0, false, 0, false, false, nil)
            ArmScanTimeout()
            return true
        end
    end

    -- Immediate scan of currently visible page if query is on cooldown
    local batch = ScanCurrentClassicPage()
    if batch and batch > 0 then
        CommitScanBuffer()
        return true
    end
    print(ADDON_PREFIX .. "Open the Auction House window first, then run |cffffd100/fm scan|r.")
    isScanning = false
    return false
end

-- ============================================================================
-- Tooltip Price Injection (12.0 C_TooltipInfo / GameTooltip Compatible)
-- ============================================================================
local function FormatAge(lastSeen)
    local ageHours = math.max(0, math.floor((time() - (lastSeen or time())) / 3600))
    return ageHours == 0 and "<1h ago" or (tostring(ageHours) .. "h ago")
end

-- Cheapest / priciest suffix seen in the item's most recent scan
local function GetVariantRange(rec)
    if type(rec.variants) ~= "table" then return nil end
    local lo, hi, n = nil, nil, 0
    for _, v in pairs(rec.variants) do
        if v.minBuyout and v.minBuyout > 0 and (v.lastSeen or 0) >= (rec.lastSeen or 0) then
            n = n + 1
            if not lo or v.minBuyout < lo then lo = v.minBuyout end
            if not hi or v.minBuyout > hi then hi = v.minBuyout end
        end
    end
    if n == 0 then return nil end
    return lo, hi, n
end

-- ============================================================================
-- Shopping List (imported from the website: Item Database -> Lists -> Copy)
-- ============================================================================
-- Format: FMSL1:itemID,qty,maxEachCopper;itemID,qty,maxEachCopper;...
-- Stored in ForeverMarketDB.shoppingList as { [itemID] = { qty = n, max = copper } }.
local SHOP_PREFIX = "FMSL1:"
local shopFrame

local function GetShoppingList()
    if not ForeverMarketDB then return {} end
    if type(ForeverMarketDB.shoppingList) ~= "table" then ForeverMarketDB.shoppingList = {} end
    return ForeverMarketDB.shoppingList
end

-- Returns the decoded list and how many entries it has, or nil and an error message.
local function DecodeShoppingList(text)
    if type(text) ~= "string" then return nil, "Nothing to import." end
    text = text:gsub("^%s+", ""):gsub("%s+$", "")
    if text:sub(1, #SHOP_PREFIX) ~= SHOP_PREFIX then
        return nil, "That isn't a ForeverMarket shopping list (it should start with " .. SHOP_PREFIX .. ")."
    end
    local list, count = {}, 0
    for entry in text:sub(#SHOP_PREFIX + 1):gmatch("[^;]+") do
        local id, qty, max = entry:match("^%s*(%d+)%s*,%s*(%d+)%s*,%s*(%d+)%s*$")
        id, qty, max = tonumber(id), tonumber(qty), tonumber(max)
        if id and qty and qty > 0 then
            if not list[id] then count = count + 1 end
            list[id] = { qty = qty, max = max or 0 }
        end
    end
    if count == 0 then return nil, "The list was empty or couldn't be read." end
    return list, count
end

local function ShoppingItemName(itemID)
    local bucket = GetActiveBucket()
    local rec = bucket and bucket.items and bucket.items[itemID]
    local name = C_Item and C_Item.GetItemInfo and C_Item.GetItemInfo(itemID)
    if CanAccess(name) and type(name) == "string" and name ~= "" then return name end
    return (rec and rec.name) or ("Item " .. itemID)
end

-- One line per item: name, quantity, max price, and the cached AH price (green when under max).
local function ShoppingListLines()
    local bucket = GetActiveBucket()
    local rows = {}
    for itemID, e in pairs(GetShoppingList()) do
        rows[#rows + 1] = { id = itemID, e = e, name = ShoppingItemName(itemID) }
    end
    table.sort(rows, function(a, b) return a.name < b.name end)
    local lines, total = {}, 0
    for _, r in ipairs(rows) do
        local rec = bucket and bucket.items and bucket.items[r.id]
        local now = rec and rec.minBuyout
        local priceTxt
        if now then
            total = total + now * r.e.qty
            local ok = (r.e.max or 0) == 0 or now <= r.e.max
            local icon = ok and "Interface\\RaidFrame\\ReadyCheck-Ready" or "Interface\\RaidFrame\\ReadyCheck-NotReady"
            priceTxt = "|T" .. icon .. ":12|t " .. FormatCopper(now)
        else
            priceTxt = "|cff888888not in your last scan|r"
        end
        local maxTxt = (r.e.max or 0) > 0 and (" |cff888888max|r " .. FormatCopper(r.e.max)) or ""
        lines[#lines + 1] = string.format("|cffffd100%dx|r %s%s  |cff888888now|r %s", r.e.qty, r.name, maxTxt, priceTxt)
    end
    return lines, total, #rows
end

local function RefreshShoppingFrame()
    if not shopFrame or not shopFrame:IsShown() then return end
    local lines, total, n = ShoppingListLines()
    if n == 0 then
        shopFrame.listText:SetText("|cff888888Your list is empty. On the website, open Item Database > Lists, copy the shopping list string, paste it above and press Import.|r")
    else
        local shown = {}
        for i = 1, math.min(#lines, 18) do shown[i] = lines[i] end
        if #lines > 18 then shown[#shown + 1] = string.format("|cff888888...and %d more|r", #lines - 18) end
        shown[#shown + 1] = " "
        shown[#shown + 1] = "|cff888888Estimated cost at your last scan:|r " .. FormatCopper(total)
        shopFrame.listText:SetText(table.concat(shown, "\n"))
    end
    shopFrame.title:SetText(string.format("|cff00ccffForeverMarket|r Shopping List |cff888888(%d)|r", n))
end

local function ImportShoppingList(text)
    local list, countOrErr = DecodeShoppingList(text)
    if not list then
        print(ADDON_PREFIX .. "|cffff4444" .. countOrErr .. "|r")
        return false
    end
    ForeverMarketDB.shoppingList = list
    for itemID in pairs(list) do
        if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, itemID) end
    end
    print(string.format("%sImported |cffffd100%d|r items to your shopping list. Hover them in the AH to see what you still need.", ADDON_PREFIX, countOrErr))
    RefreshShoppingFrame()
    return true
end

local function ShowShoppingFrame()
    if not shopFrame then
        local f = CreateFrame("Frame", "ForeverMarketShoppingFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        f:SetSize(460, 420)
        f:SetPoint("CENTER")
        f:SetFrameStrata("DIALOG")
        f:SetMovable(true)
        f:EnableMouse(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", f.StopMovingOrSizing)
        f:SetClampedToScreen(true)
        if f.SetBackdrop then
            f:SetBackdrop({
                bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                tile = true, tileSize = 16, edgeSize = 14,
                insets = { left = 4, right = 4, top = 4, bottom = 4 },
            })
            f:SetBackdropColor(0.04, 0.05, 0.08, 0.96)
            f:SetBackdropBorderColor(0, 0.8, 1, 0.8)
        end
        tinsert(UISpecialFrames, "ForeverMarketShoppingFrame") -- Escape closes it

        f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        f.title:SetPoint("TOPLEFT", 14, -12)

        local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -2, -2)

        local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        hint:SetPoint("TOPLEFT", 14, -40)
        hint:SetPoint("RIGHT", -14, 0)
        hint:SetJustifyH("LEFT")
        hint:SetText("Paste the string from the website (Ctrl+V), then press Import. Importing replaces your current list.")

        local box = CreateFrame("EditBox", "ForeverMarketShoppingInput", f, "InputBoxTemplate")
        box:SetSize(300, 22)
        box:SetPoint("TOPLEFT", 20, -66)
        box:SetAutoFocus(false)
        box:SetMaxLetters(0) -- no length limit: lists can be long
        box:SetScript("OnEscapePressed", box.ClearFocus)
        box:SetScript("OnEnterPressed", function(self)
            if ImportShoppingList(self:GetText()) then self:SetText("") end
            self:ClearFocus()
        end)
        f.input = box

        local import = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        import:SetSize(110, 22)
        import:SetPoint("LEFT", box, "RIGHT", 8, 0)
        import:SetText("Import")
        import:SetScript("OnClick", function()
            if ImportShoppingList(box:GetText()) then box:SetText("") end
            box:ClearFocus()
        end)

        f.listText = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f.listText:SetPoint("TOPLEFT", 16, -100)
        f.listText:SetPoint("BOTTOMRIGHT", -16, 44)
        f.listText:SetJustifyH("LEFT")
        f.listText:SetJustifyV("TOP")

        local clear = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        clear:SetSize(110, 22)
        clear:SetPoint("BOTTOMLEFT", 14, 12)
        clear:SetText("Clear list")
        clear:SetScript("OnClick", function()
            ForeverMarketDB.shoppingList = {}
            print(ADDON_PREFIX .. "Shopping list cleared.")
            RefreshShoppingFrame()
        end)

        local footer = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        footer:SetPoint("BOTTOMRIGHT", -16, 17)
        footer:SetText("Prices are from your last /fm scan")

        f:SetScript("OnShow", RefreshShoppingFrame)
        shopFrame = f
    end
    shopFrame:Show()
    RefreshShoppingFrame()
end
ns.ShowShoppingFrame = ShowShoppingFrame

local function AppendShoppingTooltip(tooltip, itemID)
    local e = ForeverMarketDB and type(ForeverMarketDB.shoppingList) == "table" and ForeverMarketDB.shoppingList[itemID]
    if not e then return false end
    local maxTxt = (e.max or 0) > 0 and ("  |cff888888max|r " .. FormatCopper(e.max) .. " |cff888888each|r") or ""
    tooltip:AddDoubleLine("|cff00ccffShopping list|r", string.format("|cffffd100need %d|r%s", e.qty, maxTxt))
    return true
end

local function AppendMarketTooltip(tooltip, itemID, link)
    if not ForeverMarketDB or not ForeverMarketDB.settings or not ForeverMarketDB.settings.showTooltips then
        return
    end
    if not CanAccess(itemID) or type(itemID) ~= "number" then return end

    local bucket = GetActiveBucket()
    local rec = bucket and bucket.items and bucket.items[itemID]
    if not rec or not rec.minBuyout then
        -- No price yet, but still show the shopping-list line for items on the list.
        if ForeverMarketDB.shoppingList and ForeverMarketDB.shoppingList[itemID] then
            tooltip:AddLine(" ")
            AppendShoppingTooltip(tooltip, itemID)
            tooltip:Show()
        end
        return
    end

    local _, suffixID = ParseItemLink(link)
    tooltip:AddLine(" ")

    if rec.hasVariants and type(rec.variants) == "table" then
        local lo, hi, n = GetVariantRange(rec)
        if suffixID ~= 0 then
            local v = rec.variants[tostring(suffixID)]
            if v and v.minBuyout then
                tooltip:AddDoubleLine("|cff00ccffForeverMarket Buyout|r", FormatCopper(v.minBuyout))
                tooltip:AddDoubleLine("|cff888888This Suffix Supply|r", string.format("|cffffffff%d|r |cff888888(%s)|r", v.qty or 0, FormatAge(v.lastSeen)))
            else
                tooltip:AddDoubleLine("|cff00ccffForeverMarket Buyout|r", "|cff888888No listings for this suffix|r")
            end
        else
            tooltip:AddDoubleLine("|cff00ccffForeverMarket Cheapest Suffix|r", FormatCopper(rec.minBuyout))
        end
        if lo and n > 1 then
            tooltip:AddDoubleLine(string.format("|cff888888All Suffixes (%d)|r", n), FormatCopper(lo) .. " |cff888888-|r " .. FormatCopper(hi))
        end
    else
        tooltip:AddDoubleLine("|cff00ccffForeverMarket Buyout|r", FormatCopper(rec.minBuyout))
        if rec.qty and rec.qty > 0 then
            tooltip:AddDoubleLine("|cff888888Available Supply|r", string.format("|cffffffff%d|r |cff888888(%s)|r", rec.qty, FormatAge(rec.lastSeen)))
        end
    end
    local perDay, secs = GetSalesPerDay(rec, bucket)
    if perDay then
        tooltip:AddDoubleLine("|cff888888Est. Sold/Day|r", string.format("|cffffffff%s|r |cff888888(%dh watched)|r",
            perDay >= 10 and string.format("%d", perDay) or string.format("%.1f", perDay), math.floor(secs / 3600)))
    end
    AppendShoppingTooltip(tooltip, itemID)
    tooltip:Show()
end

local function GetTooltipLink(tooltip, data)
    if data and SafeString(data.hyperlink) then return data.hyperlink end
    if tooltip and tooltip.GetItem then
        local ok, _, link = pcall(tooltip.GetItem, tooltip)
        if ok and SafeString(link) then return link end
    end
    return nil
end

local function HookTooltips()
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip, data)
            if not tooltip or (tooltip.IsForbidden and tooltip:IsForbidden()) then return end
            if data and CanAccess(data.id) and type(data.id) == "number" then
                AppendMarketTooltip(tooltip, data.id, GetTooltipLink(tooltip, data))
            end
        end)
    elseif GameTooltip and GameTooltip.HookScript then
        GameTooltip:HookScript("OnTooltipSetItem", function(self)
            if self.IsForbidden and self:IsForbidden() then return end
            local _, link = self:GetItem()
            local itemID = ParseItemLink(link)
            if itemID then
                AppendMarketTooltip(self, itemID, link)
            end
        end)
    end
end

-- ============================================================================
-- Auction House UI Header Button
-- ============================================================================
-- A small bar that sits just ABOVE the top edge of the AH window, so it never
-- overlaps Blizzard's title bar, close button, or Auctionator's tabs.
-- Shift-drag to move it; the position is saved. /fm button resets it.
local scanBar, scanButton, scanStatus = nil, nil, nil

local function FormatAgo(t)
    if not t or t <= 0 then return "never" end
    local secs = math.max(0, time() - t)
    if secs < 60 then return "just now" end
    if secs < 3600 then return string.format("%dm ago", math.floor(secs / 60)) end
    if secs < 86400 then return string.format("%dh ago", math.floor(secs / 3600)) end
    return string.format("%dd ago", math.floor(secs / 86400))
end

local function UpdateScanButtonState()
    if not scanButton then return end
    if isScanning then
        scanButton:SetText("Scanning...")
        scanButton:Disable()
        scanStatus:SetText("|cffffd100Reading auctions, please wait...|r")
    else
        local remaining = GetReplicateCooldownRemaining()
        if remaining > 0 then
            scanButton:SetText("Ready in " .. FormatCountdown(remaining))
            scanButton:Disable()
        else
            scanButton:SetText("FM Scan Market")
            scanButton:Enable()
        end
        local bucket = GetActiveBucket()
        local linkInfo = ""
        local lst, unr = tonumber(bucket.lastListings), tonumber(bucket.lastUnresolved)
        if lst and lst > 0 and unr then
            local pct = math.floor((lst - unr) * 100 / lst)
            local color = (unr == 0) and "00ff98" or ((pct == 0) and "ff4444" or "ff9933")
            linkInfo = string.format("  |cff888888Links:|r |cff%s%d%%|r", color, pct)
        end
        scanStatus:SetText(string.format("|cff00ccffForeverMarket|r  |cff888888Last scan:|r |cffffffff%s|r  |cff888888(%d items)|r%s",
            FormatAgo(bucket.lastScanTime), bucket.lastScanCount or 0, linkInfo))
    end
end
ns.UpdateScanButtonState = UpdateScanButtonState

local function PositionScanBar(parent)
    scanBar:ClearAllPoints()
    local pos = ForeverMarketDB and ForeverMarketDB.settings and ForeverMarketDB.settings.buttonPos
    if pos and pos.x and pos.y then
        scanBar:SetPoint("BOTTOMLEFT", parent, "TOPLEFT", pos.x, pos.y)
    else
        scanBar:SetPoint("BOTTOMRIGHT", parent, "TOPRIGHT", -4, 2)
    end
end

local function AttachAuctionButton()
    local parent = AuctionHouseFrame or AuctionFrame
    if not parent then return false end
    if scanBar then
        if scanBar:GetParent() ~= parent then
            scanBar:SetParent(parent)
            PositionScanBar(parent)
        end
        UpdateScanButtonState()
        return true
    end

    scanBar = CreateFrame("Frame", "ForeverMarketScanBar", parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    scanBar:SetSize(360, 28)
    scanBar:SetFrameStrata("HIGH")
    if scanBar.SetBackdrop then
        scanBar:SetBackdrop({
            bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true, tileSize = 16, edgeSize = 12,
            insets = { left = 3, right = 3, top = 3, bottom = 3 },
        })
        scanBar:SetBackdropColor(0.05, 0.05, 0.08, 0.92)
        scanBar:SetBackdropBorderColor(0, 0.8, 1, 0.8)
    end

    scanButton = CreateFrame("Button", "ForeverMarketScanButton", scanBar, "UIPanelButtonTemplate")
    scanButton:SetSize(120, 20)
    scanButton:SetPoint("RIGHT", scanBar, "RIGHT", -4, 0)
    -- Keep the tooltip working while the button is disabled for the cooldown,
    -- so hovering "Ready in m:ss" still explains why.
    if scanButton.SetMotionScriptsWhileDisabled then
        scanButton:SetMotionScriptsWhileDisabled(true)
    end
    scanButton:SetScript("OnClick", function()
        if isScanning then return end
        StartMarketScan()
        UpdateScanButtonState()
    end)
    scanButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("ForeverMarket Scan")
        GameTooltip:AddLine("Records the lowest buyout for every item and every suffix on the AH.", 1, 1, 1, true)
        GameTooltip:AddLine("The server allows one full scan every 15 minutes (shared with Auctionator).", 1, 0.82, 0, true)
        GameTooltip:AddLine("|cff888888Shift-drag the bar to move it.|r")
        GameTooltip:Show()
    end)
    scanButton:SetScript("OnLeave", function() GameTooltip:Hide() end)

    scanStatus = scanBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    scanStatus:SetPoint("LEFT", scanBar, "LEFT", 8, 0)
    scanStatus:SetPoint("RIGHT", scanButton, "LEFT", -6, 0)
    scanStatus:SetJustifyH("LEFT")

    -- Shift-drag to reposition
    scanBar:SetMovable(true)
    scanBar:EnableMouse(true)
    scanBar:RegisterForDrag("LeftButton")
    scanBar:SetScript("OnDragStart", function(self)
        if IsShiftKeyDown() then self:StartMoving() end
    end)
    scanBar:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p = self:GetParent()
        if p and p.GetLeft and self:GetLeft() and p:GetLeft() then
            ForeverMarketDB.settings.buttonPos = {
                x = math.floor(self:GetLeft() - p:GetLeft() + 0.5),
                y = math.floor(self:GetBottom() - p:GetTop() + 0.5),
            }
            PositionScanBar(p)
        end
    end)

    -- Tick the countdown once a second (OnUpdate only runs while the AH is open)
    local tick = 0
    scanBar:SetScript("OnUpdate", function(_, elapsed)
        tick = tick + elapsed
        if tick < 1 then return end
        tick = 0
        if not isScanning then UpdateScanButtonState() end
    end)

    PositionScanBar(parent)
    parent:HookScript("OnShow", UpdateScanButtonState)
    UpdateScanButtonState()
    return true
end

-- The AH window is load-on-demand; it may not exist yet when AUCTION_HOUSE_SHOW
-- fires, so retry briefly until it does.
local function TryAttachAuctionButton(attempt)
    attempt = attempt or 0
    if AttachAuctionButton() then return end
    if attempt < 10 then
        C_Timer.After(0.2, function() TryAttachAuctionButton(attempt + 1) end)
    end
end

-- ============================================================================
-- Ledger (v1.3): your own sales, purchases, expiries and cancels, read from
-- auction mail whenever the mailbox is open. Mail stays in the inbox across
-- visits, so each mail is fingerprinted (type|item|qty|price|money) plus its
-- absolute expiry time, and a fingerprint is only logged once.
-- ============================================================================
local LEDGER_KEEP_DAYS = 90
local MAIL_DUP_TOLERANCE = 120 -- seconds; same mail seen on two visits
local AUCTION_MAIL_DAYS = 30

local function Num(v)
    if CanAccess(v) and type(v) == "number" then return v end
    return 0
end

-- "Auction expired: %s" -> "^Auction expired: (.+)$"
local function SubjectPattern(fmt)
    if type(fmt) ~= "string" or fmt == "" then return nil end
    local p = fmt:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")
    p = p:gsub("%%%%s", "(.+)")
    return "^" .. p .. "$"
end

local function GetLedger(bucket)
    bucket.ledger = type(bucket.ledger) == "table" and bucket.ledger or {}
    bucket.ledgerSeen = type(bucket.ledgerSeen) == "table" and bucket.ledgerSeen or {}
    return bucket.ledger, bucket.ledgerSeen
end

-- Sale invoices only carry the item NAME; map it back to an itemID
local nameIndex
local function LookupItemID(bucket, name)
    if not name then return nil end
    if C_Item and C_Item.GetItemInfoInstant then
        local ok, id = pcall(C_Item.GetItemInfoInstant, name)
        if ok and CanAccess(id) and type(id) == "number" then return id end
    end
    if not nameIndex then
        nameIndex = {}
        for id, rec in pairs(bucket.items) do
            if rec.name then nameIndex[rec.name] = id end
            if type(rec.variants) == "table" then
                for _, v in pairs(rec.variants) do
                    if v.name then nameIndex[v.name] = id end
                end
            end
        end
    end
    return nameIndex[name]
end

local function GetMailAttachment(i)
    local name, id, count
    if GetInboxItemLink then
        local ok, link = pcall(GetInboxItemLink, i, 1)
        if ok then id = ParseItemLink(link) end
    end
    if GetInboxItem then
        local ok, n, iid, _, c = pcall(GetInboxItem, i, 1)
        if ok then
            name = SafeString(n)
            if CanAccess(c) and type(c) == "number" and c > 0 then count = c end
            if not id and CanAccess(iid) and type(iid) == "number" then id = iid end
        end
    end
    return name, id, count
end

local expiredPat, cancelledPat
local function ProcessInbox()
    if not (GetInboxNumItems and GetInboxHeaderInfo) then return end
    local okNum, num = pcall(GetInboxNumItems)
    num = okNum and Num(num) or 0
    if num <= 0 then return end

    local bucket = GetActiveBucket()
    local ledger, seen = GetLedger(bucket)
    local now = time()
    nameIndex = nil
    expiredPat = expiredPat or SubjectPattern(AUCTION_EXPIRED_MAIL_SUBJECT)
    cancelledPat = cancelledPat or SubjectPattern(AUCTION_REMOVED_MAIL_SUBJECT)
    local char = SafeString(UnitName and UnitName("player")) or "?"

    -- Forget fingerprints of mail that has expired anyway
    for k, list in pairs(seen) do
        for j = #list, 1, -1 do
            if list[j] < now then table.remove(list, j) end
        end
        if #list == 0 then seen[k] = nil end
    end

    local claimed = {}
    local added = { sold = 0, bought = 0, expired = 0, cancelled = 0 }
    local netIn, spent = 0, 0

    for i = 1, num do
        local ok, _, _, _, subject, money, _, daysLeft, itemCount, _, wasReturned, _, _, isGM = pcall(GetInboxHeaderInfo, i)
        if ok and CanAccess(daysLeft) and type(daysLeft) == "number" and not (CanAccess(isGM) and isGM) then
            subject = SafeString(subject) or ""
            money = Num(money)
            local entry
            local invType, itemName, bid, deposit, consignment, invCount
            if GetInboxInvoiceInfo then
                local okI, a, b, _, d, _, f, g, _, _, _, k = pcall(GetInboxInvoiceInfo, i)
                if okI and CanAccess(a) then
                    invType, itemName, bid, deposit, consignment, invCount = a, SafeString(b), Num(d), Num(f), Num(g), Num(k)
                end
            end
            if invType == "seller" then
                entry = { k = "sold", n = itemName, q = math.max(1, invCount), p = bid, cut = consignment, dep = deposit, net = money }
            elseif invType == "buyer" then
                local aName, aID, aCount = GetMailAttachment(i)
                entry = { k = "bought", n = itemName or aName, id = aID, q = aCount or math.max(1, invCount), p = bid }
            elseif Num(itemCount) > 0 and not (CanAccess(wasReturned) and wasReturned) then
                local nm = expiredPat and subject:match(expiredPat)
                local kind = nm and "expired"
                if not nm and cancelledPat then
                    nm = subject:match(cancelledPat)
                    kind = nm and "cancelled"
                end
                if kind then
                    local aName, aID, aCount = GetMailAttachment(i)
                    entry = { k = kind, n = nm or aName, id = aID, q = aCount or 1 }
                end
            end

            if entry then
                local fp = table.concat({ entry.k, entry.n or "", entry.q or 0, entry.p or 0, entry.net or 0 }, "|")
                local expiry = now + daysLeft * 86400
                local list = seen[fp]
                local dup = false
                if list then
                    for j, e in ipairs(list) do
                        local ck = fp .. "#" .. j
                        if not claimed[ck] and math.abs(e - expiry) <= MAIL_DUP_TOLERANCE then
                            claimed[ck] = true
                            dup = true
                            break
                        end
                    end
                end
                if not dup then
                    list = list or {}
                    seen[fp] = list
                    list[#list + 1] = expiry
                    claimed[fp .. "#" .. #list] = true
                    -- Auction mail lives 30 days, so daysLeft dates its arrival
                    entry.t = math.min(now, math.floor(now - (AUCTION_MAIL_DAYS - daysLeft) * 86400))
                    entry.c = char
                    entry.id = entry.id or LookupItemID(bucket, entry.n)
                    ledger[#ledger + 1] = entry
                    added[entry.k] = added[entry.k] + 1
                    if entry.k == "sold" then netIn = netIn + (entry.net or 0) end
                    if entry.k == "bought" then spent = spent + (entry.p or 0) end
                end
            end
        end
    end

    -- Keep 90 days
    local cutoff = now - LEDGER_KEEP_DAYS * 86400
    local keep = {}
    for _, e in ipairs(ledger) do
        if (e.t or now) >= cutoff then keep[#keep + 1] = e end
    end
    bucket.ledger = keep

    local parts = {}
    if added.sold > 0 then parts[#parts + 1] = string.format("|cff00ff98%d sold|r (+%s net)", added.sold, FormatCopper(netIn)) end
    if added.bought > 0 then parts[#parts + 1] = string.format("|cffffd100%d bought|r (%s)", added.bought, FormatCopper(spent)) end
    if added.expired > 0 then parts[#parts + 1] = string.format("|cffff9933%d expired|r", added.expired) end
    if added.cancelled > 0 then parts[#parts + 1] = string.format("|cff888888%d cancelled|r", added.cancelled) end
    if #parts > 0 then
        print(ADDON_PREFIX .. "Ledger: " .. table.concat(parts, ", ") .. ". Type |cffffd100/fm ledger|r for totals.")
    end
end

-- MAIL_INBOX_UPDATE fires in bursts; process once things settle
local inboxQueued = false
local function QueueInboxScan()
    if inboxQueued then return end
    inboxQueued = true
    C_Timer.After(0.5, function()
        inboxQueued = false
        local ok, err = pcall(ProcessInbox)
        if not ok then print(ADDON_PREFIX .. "|cffff4444Ledger error:|r " .. tostring(err)) end
    end)
end

local function FormatSigned(copper)
    if copper < 0 then return "|cffff4444-|r" .. FormatCopper(-copper) end
    if copper == 0 then return "|cff8888880|r" end
    return FormatCopper(copper)
end

local function PrintLedger(days)
    local bucket = GetActiveBucket()
    local ledger = type(bucket.ledger) == "table" and bucket.ledger or {}
    local cutoff = time() - days * 86400
    local tot = { sold = 0, soldUnits = 0, net = 0, cut = 0, bought = 0, boughtUnits = 0, spent = 0, expired = 0, cancelled = 0 }
    local per = {}
    for _, e in ipairs(ledger) do
        if (e.t or 0) >= cutoff then
            local name = e.n or "?"
            local p = per[name]
            if not p then
                p = { name = name, net = 0, spent = 0, sold = 0, bought = 0, failed = 0 }
                per[name] = p
            end
            if e.k == "sold" then
                tot.sold, tot.soldUnits = tot.sold + 1, tot.soldUnits + (e.q or 1)
                tot.net, tot.cut = tot.net + (e.net or 0), tot.cut + (e.cut or 0)
                p.net, p.sold = p.net + (e.net or 0), p.sold + (e.q or 1)
            elseif e.k == "bought" then
                tot.bought, tot.boughtUnits = tot.bought + 1, tot.boughtUnits + (e.q or 1)
                tot.spent = tot.spent + (e.p or 0)
                p.spent, p.bought = p.spent + (e.p or 0), p.bought + (e.q or 1)
            elseif e.k == "expired" or e.k == "cancelled" then
                tot[e.k] = tot[e.k] + 1
                p.failed = p.failed + 1
            end
        end
    end
    print(string.format("%sLedger, last |cffffd100%d|r days:", ADDON_PREFIX, days))
    print(string.format("  Sales: |cffffd100%d|r (%d units), net %s after %s AH cut", tot.sold, tot.soldUnits, FormatCopper(tot.net), FormatCopper(tot.cut)))
    print(string.format("  Purchases: |cffffd100%d|r (%d units), spent %s", tot.bought, tot.boughtUnits, FormatCopper(tot.spent)))
    print(string.format("  Expired: |cffffd100%d|r   Cancelled: |cffffd100%d|r", tot.expired, tot.cancelled))
    print(string.format("  Cash flow (net sales - purchases): %s", FormatSigned(tot.net - tot.spent)))

    local list = {}
    for _, p in pairs(per) do
        if p.sold > 0 or p.bought > 0 then list[#list + 1] = p end
    end
    table.sort(list, function(a, b) return (a.net - a.spent) > (b.net - b.spent) end)
    if #list > 0 then
        print("  |cff00ccffTop items:|r")
        for i = 1, math.min(5, #list) do
            local p = list[i]
            print(string.format("    %s: %s  |cff888888(sold %d, bought %d, failed %d)|r", p.name, FormatSigned(p.net - p.spent), p.sold, p.bought, p.failed))
        end
    end
    print("  |cff888888Deposits lost on expired auctions aren't in the mail, so they're not counted.|r")
end

-- ============================================================================
-- Event Frame & Slash Commands
-- ============================================================================
local function SafeRegisterEvent(frame, event)
    if not frame or not event then return end
    if C_EventUtils and C_EventUtils.IsEventValid and not C_EventUtils.IsEventValid(event) then
        return
    end
    pcall(frame.RegisterEvent, frame, event)
end

local eventFrame = CreateFrame("Frame", "ForeverMarketEventFrame")
SafeRegisterEvent(eventFrame, "ADDON_LOADED")
SafeRegisterEvent(eventFrame, "PLAYER_LOGIN")
SafeRegisterEvent(eventFrame, "AUCTION_HOUSE_SHOW")
SafeRegisterEvent(eventFrame, "AUCTION_ITEM_LIST_UPDATE")
SafeRegisterEvent(eventFrame, "REPLICATE_ITEM_LIST_UPDATE")
SafeRegisterEvent(eventFrame, "COMMODITY_SEARCH_RESULTS_UPDATED")
SafeRegisterEvent(eventFrame, "ITEM_SEARCH_RESULTS_UPDATED")
SafeRegisterEvent(eventFrame, "MAIL_INBOX_UPDATE")

eventFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "MAIL_INBOX_UPDATE" then
        QueueInboxScan()
    elseif event == "ADDON_LOADED" and arg1 == addonName then
        ForeverMarketDB = MergeDefaults(DEFAULT_DB, ForeverMarketDB)
        ForeverMarketDB.version = VERSION
    elseif event == "ADDON_LOADED" and (arg1 == "Blizzard_AuctionHouseUI" or arg1 == "Blizzard_AuctionUI") then
        TryAttachAuctionButton()
    elseif event == "PLAYER_LOGIN" then
        HookTooltips()
        local bucket, key = GetActiveBucket()
        local count = 0
        for _ in pairs(bucket.items) do count = count + 1 end
        print(string.format("%sv%s loaded (%s: |cffffd100%d|r items cached). Type |cffffd100/fm|r for commands.", ADDON_PREFIX, VERSION, key, count))
    elseif event == "AUCTION_HOUSE_SHOW" then
        TryAttachAuctionButton()
        if ForeverMarketDB and ForeverMarketDB.settings and ForeverMarketDB.settings.autoScanOnOpen then
            C_Timer.After(0.5, function()
                StartMarketScan(false, true)
                if ns.UpdateScanButtonState then ns.UpdateScanButtonState() end
            end)
        end
    elseif event == "REPLICATE_ITEM_LIST_UPDATE" then
        if isScanning and not replicateCollected then
            ProcessReplicatedScan()
        end
    elseif event == "AUCTION_ITEM_LIST_UPDATE" then
        if not isScanning then return end
        local batch, total = ScanCurrentClassicPage()
        if batch == 0 and next(activeScanBuffer) then
            CommitScanBuffer()
        elseif batch > 0 then
            local perPage = NUM_AUCTION_ITEMS_PER_PAGE or 50
            if batch >= total or batch > perPage or (scanPage + 1) * perPage >= total then
                CommitScanBuffer()
            else
                scanPage = scanPage + 1
                C_Timer.After(0.35, function()
                    if CanSendAuctionQuery and CanSendAuctionQuery() then
                        QueryAuctionItems("", nil, nil, scanPage, false, 0, false, false, nil)
                    else
                        CommitScanBuffer()
                    end
                end)
            end
        end
    end
end)

SLASH_FOREVERMARKET1 = "/fm"
SLASH_FOREVERMARKET2 = "/forevermarket"
SlashCmdList["FOREVERMARKET"] = function(msg)
    local cmd, arg = (msg or ""):lower():match("^%s*(%S*)%s*(%S*)")
    cmd = cmd or ""
    if cmd == "scan" then
        if isScanning then
            print(ADDON_PREFIX .. "A scan is already running.")
            return
        end
        StartMarketScan(arg == "force")
        if ns.UpdateScanButtonState then ns.UpdateScanButtonState() end
    elseif cmd == "button" then
        ForeverMarketDB.settings.buttonPos = nil
        if scanBar and scanBar:GetParent() then PositionScanBar(scanBar:GetParent()) end
        print(ADDON_PREFIX .. "Scan button moved back to its default spot above the Auction House window.")
    elseif cmd == "autoscan" then
        ForeverMarketDB.settings = ForeverMarketDB.settings or {}
        ForeverMarketDB.settings.autoScanOnOpen = not ForeverMarketDB.settings.autoScanOnOpen
        local state = ForeverMarketDB.settings.autoScanOnOpen and "|cff00ff98ENABLED|r" or "|cffff4444DISABLED|r"
        print(string.format("%sAuto-scan on Auction House open is now %s.", ADDON_PREFIX, state))
    elseif cmd == "status" then
        local bucket, key = GetActiveBucket()
        local count = 0
        for _ in pairs(bucket.items) do count = count + 1 end
        local lastStr = bucket.lastScanTime > 0 and date("%Y-%m-%d %H:%M", bucket.lastScanTime) or "Never"
        print(string.format("%sBucket: |cffffd100%s|r | Cached Items: |cff00ff98%d|r | Last Scan: |cff38bdf8%s|r", ADDON_PREFIX, key, count, lastStr))
    elseif cmd == "deals" then
        local bucket = GetActiveBucket()
        local deals = 0
        print(ADDON_PREFIX .. "Scanning cached auctions for vendor arbitrage flips...")
        for itemID, rec in pairs(bucket.items) do
            if C_Item and C_Item.GetItemInfo and rec.minBuyout then
                local name, link, _, _, _, _, _, _, _, _, vendorPrice = C_Item.GetItemInfo(itemID)
                if CanAccess(vendorPrice) and type(vendorPrice) == "number" and vendorPrice > 0 and rec.minBuyout < vendorPrice then
                    if rec.hasVariants and type(rec.variants) == "table" then
                        for _, v in pairs(rec.variants) do
                            if v.minBuyout and v.minBuyout < vendorPrice and (v.lastSeen or 0) >= (rec.lastSeen or 0) then
                                deals = deals + 1
                                print(string.format("  • %s (ID %d): Buyout %s < Vendor %s (Profit: %s)", v.name or rec.name or tostring(itemID), itemID, FormatCopper(v.minBuyout), FormatCopper(vendorPrice), FormatCopper(vendorPrice - v.minBuyout)))
                            end
                        end
                    else
                        deals = deals + 1
                        local profit = vendorPrice - rec.minBuyout
                        print(string.format("  • %s (ID %d): Buyout %s < Vendor %s (Profit: %s)", link or name or rec.name or tostring(itemID), itemID, FormatCopper(rec.minBuyout), FormatCopper(vendorPrice), FormatCopper(profit)))
                    end
                end
            end
        end
        if deals == 0 then
            print(ADDON_PREFIX .. "No direct vendor arbitrage flips found in current snapshot.")
        end
    elseif cmd == "suffixes" or cmd == "suffix" then
        -- /fm suffixes <shift-click item link>  or  /fm suffixes <itemID>
        local arg = (msg or ""):match("^%s*%S+%s+(.+)$") or ""
        local itemID = ParseItemLink(arg) or tonumber(arg:match("^%s*(%d+)"))
        if not itemID then
            print(ADDON_PREFIX .. "Usage: |cffffd100/fm suffixes|r <shift-click an item> or <itemID>")
            return
        end
        local bucket = GetActiveBucket()
        local rec = bucket.items[itemID]
        if not rec then
            print(string.format("%sNo cached data for item %d.", ADDON_PREFIX, itemID))
            return
        end
        if not rec.hasVariants or type(rec.variants) ~= "table" then
            print(string.format("%s%s has no random suffixes on record. Buyout: %s", ADDON_PREFIX, rec.name or tostring(itemID), FormatCopper(rec.minBuyout)))
            return
        end
        local list = {}
        for vKey, v in pairs(rec.variants) do
            list[#list + 1] = { key = vKey, v = v }
        end
        table.sort(list, function(a, b) return (a.v.minBuyout or 0) < (b.v.minBuyout or 0) end)
        print(string.format("%s%s — |cffffd100%d|r suffix variants:", ADDON_PREFIX, rec.name or tostring(itemID), #list))
        for _, e in ipairs(list) do
            local stale = (e.v.lastSeen or 0) < (rec.lastSeen or 0) and " |cff888888(not in last scan)|r" or ""
            print(string.format("  • %s: %s  |cff888888x%d, %s|r%s", e.v.suffix or e.v.name or ("suffix " .. e.key), FormatCopper(e.v.minBuyout), e.v.qty or 0, FormatAge(e.v.lastSeen), stale))
        end
    elseif cmd == "linkcheck" then
        local bucket = GetActiveBucket()
        local d = bucket.lastLinkDiag
        if type(d) ~= "table" or not d.rows then
            print(ADDON_PREFIX .. "No link diagnostics yet. Run a full scan first.")
            return
        end
        print(string.format("%sItem-link report for the scan at |cffffd100%s|r:", ADDON_PREFIX, d.time and date("%I:%M %p", d.time) or "?"))
        print(string.format("  Rows read: |cffffd100%d|r   With a link on first read: |cffffd100%d|r   hasAllInfo=false: |cffffd100%d|r", d.rows, d.withLink or 0, d.notLoaded or 0))
        print(string.format("  Link API present: %s   Errors: %d   Protected values: %d   Empty: %d   Unparseable: %d",
            d.apiMissing and "|cffff4444no|r" or "|cff00ff98yes|r", d.errors or 0, d.secret or 0, d.empty or 0, d.parseFail or 0))
        print(string.format("  Resolved while waiting: |cffffd100%d|r   Still missing when saved: |cffffd100%d|r",
            math.max(0, (d.rows - (d.withLink or 0)) - (d.stillPending or 0)), d.stillPending or 0))
        if d.sample then print("  Sample unparseable link: " .. tostring(d.sample):gsub("|", "||")) end
        local verdict = DescribeLinkDiag(d)
        if not verdict then
            if (d.stillPending or 0) == 0 then
                verdict = string.format("|cff00ff98Success: all %d listings have item links, so suffix variants are priced individually.|r", d.rows)
            else
                verdict = "|cff00ff98No link problems detected.|r"
            end
        end
        print("  " .. verdict)
    elseif cmd == "list" then
        -- /fm list            open the shopping list window (paste box + list)
        -- /fm list clear      empty the list
        -- /fm list FMSL1:...  import directly (only for short lists: chat lines max 255 chars)
        local rest = (msg or ""):match("^%s*%S+%s+(.+)$") or ""
        if rest:lower() == "clear" then
            ForeverMarketDB.shoppingList = {}
            print(ADDON_PREFIX .. "Shopping list cleared.")
            RefreshShoppingFrame()
        elseif rest:sub(1, #SHOP_PREFIX) == SHOP_PREFIX then
            ImportShoppingList(rest)
        else
            ShowShoppingFrame()
        end
    elseif cmd == "ledger" then
        PrintLedger(math.max(1, math.min(90, tonumber(arg) or 7)))
    elseif cmd == "top" then
        -- Fastest movers by estimated daily gold turnover (sold/day x price)
        local bucket = GetActiveBucket()
        local list = {}
        for itemID, rec in pairs(bucket.items) do
            local perDay = GetSalesPerDay(rec, bucket)
            if perDay and perDay > 0 and rec.minBuyout then
                list[#list + 1] = { id = itemID, rec = rec, perDay = perDay, turnover = perDay * rec.minBuyout }
            end
        end
        if #list == 0 then
            print(ADDON_PREFIX .. "No sales estimates yet. Run two full scans less than 12 hours apart.")
            return
        end
        table.sort(list, function(a, b) return a.turnover > b.turnover end)
        local n = math.max(1, math.min(50, tonumber(arg) or 15))
        print(string.format("%sTop %d items by estimated daily turnover (lower bound):", ADDON_PREFIX, math.min(n, #list)))
        for i = 1, math.min(n, #list) do
            local e = list[i]
            print(string.format("  %d. %s: |cffffffff%.1f|r/day at %s  |cff888888(~%s/day)|r", i, e.rec.name or tostring(e.id), e.perDay, FormatCopper(e.rec.minBuyout), FormatCopper(math.floor(e.turnover))))
        end
    elseif cmd == "clear" then
        local bucket, key = GetActiveBucket()
        bucket.items = {}
        bucket.lastScanTime = 0
        bucket.lastScanCount = 0
        print(ADDON_PREFIX .. "Cleared cached market data for " .. key .. ".")
    else
        print(ADDON_PREFIX .. "Commands:")
        print("  |cffffd100/fm scan|r — Scan the open Auction House and record lowest unit buyouts")
        print("  |cffffd100/fm autoscan|r — Toggle automatic scan whenever opening the Auction House")
        print("  |cffffd100/fm button|r — Reset the AH scan button to its default position")
        print("  |cffffd100/fm status|r — Show active ruleset/faction bucket and cached item count")
        print("  |cffffd100/fm deals|r — List items currently listed below vendor sell price")
        print("  |cffffd100/fm suffixes <item>|r — Show prices for every suffix of an item (of the Eagle, of the Monkey, ...)")
        print("  |cffffd100/fm linkcheck|r — Explain why item links (suffixes) were missing in the last scan")
        print("  |cffffd100/fm top [n]|r — Fastest-selling items by estimated gold turnover per day")
        print("  |cffffd100/fm ledger [days]|r — Your AH sales, purchases and expiries (logged from the mailbox)")
        print("  |cffffd100/fm list|r — Shopping list from the website: paste, import, see what to buy (|cffffd100/fm list clear|r empties it)")
        print("  |cffffd100/fm clear|r — Clear cached market prices for the active ruleset/faction")
    end
end

-- ============================================================================
-- Public Inter-Addon API for Suite Integration (e.g. ForeverLiquid)
-- ============================================================================
local PublicAPI = {}

function PublicAPI:IsAvailable()
    if not ForeverMarketDB or not ForeverMarketDB.realms then return false end
    local bucket = GetActiveBucket()
    return bucket and bucket.items and next(bucket.items) ~= nil
end

function PublicAPI:GetActiveBucket()
    return GetActiveBucket()
end

function PublicAPI:GetRealmFactionKey()
    return GetRealmFactionKey()
end

function PublicAPI:GetItemRecord(itemID)
    if not CanAccess(itemID) or type(itemID) ~= "number" then return nil end
    local bucket = GetActiveBucket()
    if bucket and bucket.items and bucket.items[itemID] then
        return bucket.items[itemID]
    end
    -- Fallback across any realm/faction bucket in ForeverMarketDB
    if ForeverMarketDB and ForeverMarketDB.realms then
        for _, b in pairs(ForeverMarketDB.realms) do
            if b and b.items and b.items[itemID] then
                return b.items[itemID]
            end
        end
    end
    return nil
end

function PublicAPI:GetItemPrice(itemID)
    local rec = self:GetItemRecord(itemID)
    if rec and rec.minBuyout and rec.minBuyout > 0 then
        return rec.minBuyout, rec.qty or 1, rec.lastSeen or 0, rec.listings or 1, rec.name
    end
    return nil
end

-- Suffix-aware lookup: pass a full item link (e.g. from loot or bags).
-- Returns the price for that exact suffix; falls back to the base-item price
-- for items without random suffixes. Returns nil if the suffix was never seen.
function PublicAPI:GetItemPriceByLink(link)
    local itemID, suffixID = ParseItemLink(link)
    if not itemID then return nil end
    local rec = self:GetItemRecord(itemID)
    if not rec then return nil end
    if suffixID ~= 0 and rec.hasVariants and type(rec.variants) == "table" then
        local v = rec.variants[tostring(suffixID)]
        if v and v.minBuyout and v.minBuyout > 0 then
            return v.minBuyout, v.qty or 1, v.lastSeen or 0, v.listings or 1, v.name
        end
        return nil
    end
    return self:GetItemPrice(itemID)
end

function PublicAPI:GetItemVariants(itemID)
    local rec = self:GetItemRecord(itemID)
    if rec and rec.hasVariants and type(rec.variants) == "table" then
        return rec.variants
    end
    return nil
end

-- Estimated units sold per day (7-day window, lower bound) and seconds observed
function PublicAPI:GetSalesPerDay(itemID)
    local rec = self:GetItemRecord(itemID)
    if not rec then return nil end
    return GetSalesPerDay(rec, GetActiveBucket())
end

-- Raw ledger entries: { t, k = sold|bought|expired|cancelled, n, id, q, p, cut, dep, net, c }
function PublicAPI:GetLedger()
    local bucket = GetActiveBucket()
    return type(bucket.ledger) == "table" and bucket.ledger or {}
end

function PublicAPI:ParseItemLink(link)
    return ParseItemLink(link)
end

function PublicAPI:FormatMoney(copper)
    return FormatCopper(copper)
end

_G.ForeverMarket = PublicAPI

